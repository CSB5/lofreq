import sys
assert sys.version_info.major == 2 and sys.version_info.minor == 7, ("Need Python 2.7")
