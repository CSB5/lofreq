#ifndef LOFREQ_BAMSTATS_H
#define LOFREQ_BAMSTATS_H

int main_bamstats(int argc, char *argv[]);


#endif
