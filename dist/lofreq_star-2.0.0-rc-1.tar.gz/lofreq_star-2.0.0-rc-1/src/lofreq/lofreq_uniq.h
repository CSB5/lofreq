#ifndef LOFREQ_UNIQ_H
#define LOFREQ_UNIQ_H

int main_uniq(int argc, char *argv[]);

#endif
