#ifndef LOFREQ_SNPCALLER_H
#define LOFREQ_SNPCALLER_H

int main_call(int argc, char *argv[]);

#endif
