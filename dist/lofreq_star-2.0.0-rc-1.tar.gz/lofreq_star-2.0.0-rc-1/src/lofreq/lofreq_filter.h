#ifndef LOFREQ_FILTER_H
#define LOFREQ_FILTER_H

int main_filter(int argc, char *argv[]);

#endif
