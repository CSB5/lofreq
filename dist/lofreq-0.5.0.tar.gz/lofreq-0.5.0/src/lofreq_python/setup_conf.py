# automagically set by autotools
PACKAGE_NAME="Lofreq"
PACKAGE_TARNAME="lofreq"
PACKAGE_VERSION="0.5.0"
PACKAGE_STRING="Lofreq 0.5.0"
PACKAGE_BUGREPORT="wilma@gis.a-star.edu.sg"
