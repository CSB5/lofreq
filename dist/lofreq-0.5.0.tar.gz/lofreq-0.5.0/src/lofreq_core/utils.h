int file_exists(char *fname);
int ae_load_file_to_memory(const char *filename, char **result);

