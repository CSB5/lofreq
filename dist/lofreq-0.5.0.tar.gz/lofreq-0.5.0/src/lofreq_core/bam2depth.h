int depth_stats(double *ret_mean, long int *ret_num_nonzero_pos,
                char *bam_file, 
                char *usr_reg, char *usr_bed_file,
                int *usr_baseQ, int *usr_mapQ);
