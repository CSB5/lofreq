#!/usr/bin/env python
"""FIXME
"""

# Copyright (C) 2011, 2012 Genome Institute of Singapore
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301 USA.



from __future__ import division

__author__ = "Andreas Wilm"
__version__ = "0.1"
__email__ = "wilma@gis.a-star.edu.sg"
__copyright__ = ""
__license__ = ""
__credits__ = [""]
__status__ = ""


#--- standard library imports
#
import sys
import logging
# optparse deprecated from Python 2.7 on
from optparse import OptionParser
import os


#--- third-party imports
#
from lofreq import snp

#--- project specific imports
#



#global logger
# http://docs.python.org/library/logging.html
LOG = logging.getLogger("")
logging.basicConfig(level=logging.WARN,
                    format='%(levelname)s [%(asctime)s]: %(message)s')


    


def cmdline_parser():
    """
    creates an OptionParser instance
    """

    # http://docs.python.org/library/optparse.html
    usage = "%prog: FIXME.\n" \
            "usage: %prog [options]"
    parser = OptionParser(usage=usage)

    parser.add_option("-v", "--verbose",
                      action="store_true", dest="verbose",
                      help="be verbose")
    parser.add_option("", "--debug",
                      action="store_true", dest="debug",
                      help="debugging")
    parser.add_option("-i", "--snpfile",
                      dest="fsnp", # type="string|int|float"
                      help="SNP input file")
    #parser.add_option("-t", "--freqthres",
    #                  dest="freqthresh", type="float",
    #                  help="Ignore SNPs below this freq treshold")
    #parser.add_option("", "--covcap",
    #                  dest="max_cov",
    #                  default=sys.maxint, type=int,
    #                  help="Optional: Coverage Cap")
    #parser.add_option("", "--mincov",
    #                  dest="min_cov",
    #                  default=1, type=int,
    #                  help="Optional: Min coverage")    

    return parser



def main():
    """
    The main function
    """

    
    parser = cmdline_parser()
    (opts, args) = parser.parse_args()

    #if len(args):
    #    parser.error("Unrecognized arguments found: %s." % (
    #        ' '.join(args)))
    #    sys.exit(1)
        
    if opts.verbose:
        LOG.setLevel(logging.INFO)
    if opts.debug:
        LOG.setLevel(logging.DEBUG)

    if not opts.fsnp:
        parser.error("Missing SNP file argument")
        sys.exit(1)
    if not os.path.exists(opts.fsnp):
        LOG.fatal("SNP input file '%s' does not exist.\n" % opts.fsnp)
        sys.exit(1)
            

    fsnp = opts.fsnp
    snp_list_full = snp.parse_snp_file(fsnp)
    snp_list_strandbiasfiltered = []
    try:
        bonf = len(snp_list_full)
        origlen = len(snp_list_full)
        snp_list_strandbiasfiltered = [s for s in snp_list_full
                                       if float(s.info['strandbias-pvalue-uncorr'])*bonf > 0.05]
        LOG.info("Removed %d SNPs with significant strand bias (bonferroni corrected, p<=0.05)" % (origlen-len(snp_list_full)))
    except KeyError:
        LOG.fatal("%s has no usable strandbias info" % fsnp);
        sys.exit(1)

    snp.write_snp_file(sys.stdout, snp_list_strandbiasfiltered, write_header=True)

if __name__ == "__main__":
    main()
    LOG.info("successful exit")
