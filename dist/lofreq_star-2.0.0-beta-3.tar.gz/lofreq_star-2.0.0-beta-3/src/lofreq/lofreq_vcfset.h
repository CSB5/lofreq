#ifndef LOFREQ_VCFSET_H
#define LOFREQ_VCFSET_H

int main_vcfset(int argc, char *argv[]);

#endif
