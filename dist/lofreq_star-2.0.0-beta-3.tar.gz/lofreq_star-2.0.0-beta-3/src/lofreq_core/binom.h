/* -*- c-file-style: "k&r"; indent-tabs-mode: nil; -*- */
#ifndef BINOM_H
#define BINOM_H

/*********************************************************************
 *
 * FIXME license update
 *
 *
 *********************************************************************/

int binom(double *q, double *p,
          int num_trials, int num_successes, double prob_success);

#endif
